<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Simple helper to load language, etc.
 */

if (!function_exists('real_estate_module_name')) {
    function real_estate_module_name()
    {
        return 'Real Estate Plot Management';
    }
}
