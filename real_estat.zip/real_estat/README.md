# Real Estate Management Module for Perfex CRM

## Overview
Complete Real Estate Management System for managing projects, plots, bookings, and sales integrated with Perfex CRM.

## Features

### 1. **Project Management**
- Create and manage real estate projects
- Track project status (Planning, Active, Completed, On Hold)
- Assign project managers
- Monitor project statistics and revenue
- Support for multiple projects

### 2. **Plot Management**
- Add plots individually or via bulk import
- Organize plots by blocks/sectors
- Track plot details:
  - Plot number, type, area, facing
  - Dimensions and rate per unit
  - Auto-calculation of total price
  - Status tracking (Available, Booked, Sold, Reserved, Blocked)

### 3. **Booking System**
- Create bookings for available plots
- Auto-generate booking codes
- Link bookings to Perfex customers
- Apply discounts
- Flexible payment plans
- Booking status workflow:
  - Pending → Confirmed → Converted to Sale
  - Cancellation with reason tracking

### 4. **Payment Plans & Installments**
- Pre-configured payment plans:
  - One-time payment
  - 30-70 Plan (30% down, 70% installments)
  - 20-80 Plan (20% down, 80% installments)
  - Quarterly Plan
- Custom payment plans
- Auto-generation of installment schedules
- Installment frequency options (Monthly, Quarterly, Yearly)
- Track payment status
- Overdue payment alerts

### 5. **Financial Integration**
- Integration with Perfex invoice system
- Auto-generate invoices for installments
- Payment tracking and recording
- Revenue reports per project
- Customer payment history

### 6. **Team Management**
- Assign team members to projects
- Define roles and responsibilities
- Track team assignments
- Integration with Perfex staff system

### 7. **Communication Tracking**
- Log customer interactions
- Communication types:
  - Calls
  - Emails
  - Meetings
  - Site visits
- Link communications to projects, plots, or bookings
- Complete communication history

### 8. **Reports & Analytics**
- Dashboard with key metrics
- Project-wise reports
- Sales reports
- Payment reports
- Inventory status
- Customer reports

### 9. **Security & Permissions**
- Granular permission system
- Role-based access control:
  - View, Create, Edit, Delete permissions
  - Separate permissions for Projects, Plots, Bookings, Payments

## Database Schema

### Tables Created:
1. **`tbl_re_projects`** - Project master data
2. **`tbl_re_blocks`** - Blocks/Sectors within projects
3. **`tbl_re_plots`** - Individual plots with all details
4. **`tbl_re_bookings`** - Booking records
5. **`tbl_re_payment_plans`** - Payment plan templates
6. **`tbl_re_booking_installments`** - Installment schedules
7. **`tbl_re_team_assignments`** - Team member assignments
8. **`tbl_re_communications`** - Communication logs
9. **`tbl_re_custom_fields_values`** - Custom field data

## Installation

1. **Upload Module**
   - Copy the `real_estat` folder to `modules/` directory

2. **Activate Module**
   - Go to Setup → Modules
   - Find "Real Estate Management"
   - Click "Activate"

3. **Database Setup**
   - Tables will be created automatically on activation
   - Default payment plans will be inserted

4. **Configure Permissions**
   - Go to Setup → Staff → Roles
   - Set permissions for "Real Estate Projects", "Real Estate Plots", "Real Estate Bookings", "Real Estate Payments"

## Usage Guide

### Creating a Project

1. Navigate to Real Estate → Projects
2. Click "New Project"
3. Fill in project details:
   - Project Code (unique identifier)
   - Project Name
   - Location
   - Total Area
   - Status
   - Project Manager
   - Start Date & Completion Date
4. Click Submit

### Adding Plots

**Individual Plot:**
1. Go to Real Estate → Plots
2. Click "New Plot"
3. Select Project and Block (optional)
4. Enter plot details:
   - Plot Number
   - Area and Unit
   - Rate per Unit (total price auto-calculated)
   - Facing direction
   - Status
5. Click Submit

**Bulk Import:**
1. Go to Real Estate → Plots → Bulk Import
2. Download CSV template
3. Fill in plot details
4. Upload CSV file
5. Review and confirm import

### Creating a Booking

1. Navigate to Real Estate → Bookings
2. Click "New Booking"
3. Select:
   - Customer (from Perfex clients)
   - Project
   - Available Plot
4. Enter booking details:
   - Booking Date
   - Booking Amount
   - Total Amount (auto-filled from plot price)
   - Discount (if any)
   - Payment Plan
5. Click Submit
6. Installments will be auto-generated based on payment plan

### Recording Payments

1. Go to Real Estate → Payments
2. Find the booking/installment
3. Click "Record Payment"
4. Enter:
   - Payment Amount
   - Payment Date
   - Generate Invoice (optional)
5. Click Submit

### Converting Booking to Sale

1. Open the booking details
2. Ensure all payments are complete
3. Click "Convert to Sale"
4. Plot status automatically changes to "Sold"

### Cancelling a Booking

1. Open the booking details
2. Click "Cancel Booking"
3. Enter cancellation reason
4. Click Submit
5. Plot status automatically reverts to "Available"

## API Integration

### Get Available Plots
```javascript
GET /admin/real_estat/get_available_plots/{project_id}
Returns: JSON array of available plots
```

### Get Blocks by Project
```javascript
GET /admin/real_estat/get_blocks_by_project/{project_id}
Returns: JSON array of blocks
```

## Workflows

### A. Lead to Booking Flow
1. Lead created in Perfex CRM
2. Lead converted to Customer
3. Customer shown available plots
4. Plot reserved/blocked temporarily
5. Booking created with payment plan
6. Installments auto-generated
7. Booking confirmed

### B. Booking to Sale Flow
1. Booking confirmed
2. Installments paid as per schedule
3. Invoices generated for each payment
4. All payments completed
5. Booking converted to sale
6. Plot marked as sold
7. Sale documentation

### C. Payment Management Flow
1. Installment due date approaches
2. System tracks overdue payments
3. Admin records payment
4. Invoice generated (optional)
5. Payment linked to installment
6. Installment marked as paid
7. Next installment becomes due

## Customization

### Adding Custom Fields
Edit `modules/real_estat/views/[entity]/[form].php` and add custom fields to forms.

### Modifying Payment Plans
1. Go to Real Estate → Payments → Payment Plans
2. Add new plan with:
   - Plan Name
   - Down Payment Percentage
   - Number of Installments
   - Frequency

### Custom Reports
Create new views in `modules/real_estat/views/reports/` and add corresponding controller methods.

## Troubleshooting

### Module Not Appearing
- Check file permissions (755 for directories, 644 for files)
- Verify `real_estat.php` exists in module root
- Check PHP error logs

### Tables Not Created
- Manually run `modules/real_estat/install.php`
- Check database user permissions
- Verify database connection

### Permission Issues
- Go to Setup → Staff → Roles
- Enable all Real Estate permissions for Administrator role
- Re-login to apply permissions

## Support & Updates

### Version: 1.0.0
### Compatible with: Perfex CRM 2.3.0+

### Module Structure:
```
real_estat/
├── real_estat.php          # Main module file
├── install.php             # Installation script
├── controllers/
│   └── Real_estat.php      # Main controller
├── models/
│   └── Real_estate_model.php   # Data model
├── views/
│   ├── dashboard.php       # Dashboard view
│   ├── projects/           # Project views
│   ├── plots/              # Plot views
│   ├── bookings/           # Booking views
│   ├── payments/           # Payment views
│   └── reports/            # Report views
├── language/
│   └── english/
│       └── real_estat_lang.php  # English translations
└── assets/
    ├── css/
    │   └── real_estat.css  # Custom styles
    └── js/
        └── real_estat.js   # Custom JavaScript
```

## Future Enhancements

- Mobile app integration
- SMS/Email notifications for due payments
- Document management (agreements, NOCs)
- Customer portal
- Advanced reporting with charts
- Map integration for plot visualization
- WhatsApp integration
- Multi-currency support
- Advanced search and filters
- Export to PDF/Excel

## License
This module is designed for Perfex CRM and follows Perfex's licensing terms.
