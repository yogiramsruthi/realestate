# Real Estate Module - Troubleshooting Guide

## Installation & Activation Issues

### Issue: "Module Real Estate Management not found in setup/modules"

**Symptoms:**
- Real Estate module doesn't appear in Setup → Modules list
- Can't find it to activate

**Solutions:**

1. **Verify module directory exists:**
   ```powershell
   # Check if module folder exists
   Test-Path "C:\xampp\htdocs\test_real\modules\real_estat"
   ```
   - Should return `True`
   - If not, module files weren't created properly

2. **Check real_estat.php exists:**
   ```powershell
   Test-Path "C:\xampp\htdocs\test_real\modules\real_estat\real_estat.php"
   ```
   - Must return `True` - this is the main module file

3. **Clear Perfex cache:**
   - Delete all files in `application/cache/` folder
   - Reload Perfex admin page

4. **Check module directory permissions:**
   - Right-click `modules/real_estat` → Properties
   - Ensure your user has Read/Modify permissions
   - If not, right-click → Properties → Security → Edit → Add your user with Full Control

5. **Verify modules directory writable:**
   - Check `modules/` folder has write permissions
   - PHP must be able to read/write to module files

**If still not working:**
- Deactivate all other custom modules temporarily
- Refresh Setup → Modules page
- Check browser console (F12) for JavaScript errors

---

### Issue: "Fatal error: Class not found" after activation

**Symptoms:**
- See error after clicking Activate
- Error mentions `Real_estat` or `Real_estate_model` class

**Solutions:**

1. **Verify controller file:**
   ```powershell
   Test-Path "C:\xampp\htdocs\test_real\modules\real_estat\controllers\Real_estat.php"
   ```

2. **Verify model file:**
   ```powershell
   Test-Path "C:\xampp\htdocs\test_real\modules\real_estat\models\Real_estate_model.php"
   ```

3. **Check file permissions** on controller and model files
   - Files must be readable by PHP

4. **Verify file encodings:**
   - Files should be UTF-8 (not UTF-8 with BOM)
   - Check first line of Real_estat.php should be `<?php` with no spaces before

5. **Clear opcache:**
   ```php
   // Add to temp file, then delete
   opcache_reset();
   ```

---

### Issue: "Database tables not created" after activation

**Symptoms:**
- Module activates but tables don't exist
- Errors when trying to create projects/plots/bookings
- Database looks empty

**Solutions:**

1. **Run install script manually:**
   - Navigate to: `http://localhost/test_real/admin/real_estat/`
   - Should trigger install.php automatically
   - If not, manually copy/paste this into phpMyAdmin SQL console:
     ```sql
     -- Run the SQL from modules/real_estat/install.php
     -- Check the ACTIVATE_CHECKLIST.md for full SQL
     ```

2. **Check database user permissions:**
   - User used by Perfex must have CREATE TABLE privileges
   - Log in to phpMyAdmin with Perfex database user
   - Should be able to create tables

3. **Verify table prefix:**
   - Check `application/config/database.php` for `$db['default']['dbprefix']`
   - Tables should be created with this prefix (e.g., `tbl_re_projects`)

4. **Check MySQL error logs:**
   - Look in `C:\xampp\mysql\data\*.err` files
   - May show why table creation failed

5. **Run verification SQL:**
   ```sql
   -- Verify tables exist
   SELECT TABLE_NAME FROM information_schema.TABLES 
   WHERE TABLE_SCHEMA = 'test_real' 
   AND TABLE_NAME LIKE '%_re_%';
   
   -- Count should be 9
   ```

---

## Form & Display Issues

### Issue: Form fields not displaying (blank forms)

**Symptoms:**
- Project/Plot/Booking form is empty or missing fields
- Only see form container, no input fields
- Was reported and fixed: "some fields are missing in New Projects"

**Solutions:**

1. **Clear browser cache:**
   - Press `Ctrl+Shift+Delete`
   - Clear all history and cached images/files
   - Reload page

2. **Use private/incognito window:**
   - May have cached CSS/JavaScript issues
   - Test in new private window

3. **Check browser console for errors:**
   - Press `F12` to open Developer Tools
   - Go to Console tab
   - Look for red errors
   - Common error: "selectpicker is not defined"

4. **Verify CSS/JS files exist:**
   ```powershell
   Test-Path "C:\xampp\htdocs\test_real\modules\real_estat\assets\css\real_estat.css"
   Test-Path "C:\xampp\htdocs\test_real\modules\real_estat\assets\js\real_estat.js"
   ```
   - Both should exist and be readable

5. **Check if form fields render as HTML:**
   - Right-click form → Inspect Element
   - Should see `<input>` and `<select>` tags
   - If missing, view file may not be loaded correctly

6. **Verify view file syntax:**
   - Check `projects/project.php` doesn't have PHP errors
   - First line should be `<?php defined('BASEPATH') or exit('No direct script access allowed');`
   - No closing `?>` tag at end

**Recent Fix Applied:**
- This issue was fixed by replacing Perfex helper functions with native HTML elements
- All forms now use `<input>`, `<select>`, `<textarea>` tags directly
- CSS classes: `form-control`, `form-group`, `selectpicker`

---

### Issue: Dropdowns not working (selectpicker)

**Symptoms:**
- Dropdown shows but doesn't expand when clicked
- Shows "undefined" or blank options
- Dropdown arrows not visible

**Solutions:**

1. **Verify selectpicker jQuery plugin loaded:**
   - Open page source (Ctrl+U)
   - Search for "selectpicker"
   - Should see `<link>` tags for CSS and `<script>` tags for JS
   - Should be in Perfex theme files

2. **Check jQuery loaded before selectpicker:**
   - Look at page source
   - jQuery must be included before selectpicker JavaScript
   - Check order in theme header

3. **Manually initialize selectpicker:**
   - Open browser console (F12)
   - Paste: `$('.selectpicker').selectpicker('refresh');`
   - Should fix dropdowns if plugin is loaded

4. **Check for JavaScript errors:**
   - Press F12 → Console tab
   - Look for red errors
   - Error may explain why selectpicker not working

5. **Verify select element has class:**
   - Inspect dropdown element
   - Should have `class="form-control selectpicker"`
   - If missing, add it to view file

---

### Issue: Date picker not working

**Symptoms:**
- Date input shows text field instead of calendar
- Can't pick dates visually
- Manual date entry required

**Solutions:**

1. **Use HTML5 native date input:**
   - Input type should be `<input type="date">`
   - Modern browsers support this natively
   - Falls back to text input in older browsers

2. **Add jQuery UI datepicker as fallback:**
   ```html
   <input type="text" class="form-control datepicker" name="start_date">
   <script>
   $(function() {
       $('.datepicker').datepicker({
           dateFormat: 'yy-mm-dd'
       });
   });
   </script>
   ```

3. **For better UX, use Bootstrap DatePicker:**
   - Include in view file head section
   - Initialize with: `$('.date').datetimepicker({format: 'YYYY-MM-DD'})`

---

## Permission & Access Issues

### Issue: "Access Denied: Real Estate Projects"

**Symptoms:**
- Click Real Estate menu item, see access denied message
- Can't create/edit/delete anything
- Even Admin role denied access

**Solutions:**

1. **Verify module activated:**
   - Go to Setup → Modules
   - Check Real Estate Management is marked as "Activated"
   - If not, click Activate button

2. **Configure your role permissions:**
   - Go to Setup → Staff → Roles
   - Edit Administrator (or your role)
   - Scroll to Real Estate section
   - Enable checkboxes:
     - ☑ Real Estate Projects (View)
     - ☑ Real Estate Projects (Create)
     - ☑ Real Estate Projects (Edit)
     - ☑ Real Estate Projects (Delete)
   - Click Save

3. **Log out and log back in:**
   - Permissions cached in session
   - Must logout completely for new permissions
   - Close all browser tabs, then reopen Perfex

4. **Check permission names:**
   - Permissions registered: `real_estate_projects`, `real_estate_plots`, `real_estate_bookings`, `real_estate_payments`
   - Must exactly match what's shown in Roles editor

5. **Verify module hook registered permissions:**
   - Check `real_estat.php` file
   - Should contain `register_permission_groups()` hook
   - If missing, permissions won't register

---

### Issue: Create/Edit buttons disappear for non-Admin users

**Symptoms:**
- Admin can see all buttons
- Other users see only View access
- Create, Edit, Delete buttons hidden

**Solutions:**

1. **User's role lacks permission:**
   - Ask admin to edit user's role
   - Add required Real Estate permissions

2. **Permission checkbox not checked:**
   - Admin → Setup → Roles
   - Edit user's role
   - Check if Real Estate boxes are checked
   - If not, check them and save

3. **User still seeing old interface:**
   - User must logout and login again
   - Permissions cached in session

4. **Verify has_permission() function works:**
   - Open browser console (F12)
   - This PHP function controls button display
   - Check view file uses: `if (has_permission('real_estate_projects', '', 'create'))`

---

## Database Issues

### Issue: "Duplicate entry for key 'code'" when creating project

**Symptoms:**
- Error appears when submitting new project
- Message: "Duplicate entry for key 'code'"
- Project code already exists

**Solutions:**

1. **Use unique project code:**
   - Each project must have unique code
   - Example codes: PROJ001, DOWNTOWN-2024, MALL-NORTH
   - Check existing projects to avoid duplicates

2. **Check for old test projects:**
   ```sql
   SELECT id, code, name FROM tbl_re_projects 
   WHERE code LIKE 'TEST%' OR code LIKE 'P%';
   ```
   - Delete old test projects if needed
   - Or use different code prefix

3. **Clear project code input and try again:**
   - Remove any existing code value
   - Type new unique code
   - Submit

---

### Issue: "No available plots" when creating booking

**Symptoms:**
- Plot dropdown is empty or shows no options
- Can't select plot for booking
- Even though plots exist

**Solutions:**

1. **Check plot status:**
   ```sql
   SELECT id, plot_number, status FROM tbl_re_plots 
   WHERE project_id = 1;
   ```
   - Plots must have status = `available` to appear in booking
   - Booked/Sold plots won't appear

2. **Verify project has plots:**
   - Go to Real Estate → Plots
   - Filter by your project
   - Should show at least one plot
   - If none appear, create some first

3. **Check plot project_id matches:**
   ```sql
   SELECT * FROM tbl_re_plots 
   WHERE plot_number = 'P-001';
   ```
   - `project_id` must match selected project in booking form
   - If NULL or wrong ID, update it

4. **Try refreshing page:**
   - JavaScript may not have loaded plot list
   - Reload booking form page
   - Try again

---

### Issue: "Foreign key constraint fails" when deleting

**Symptoms:**
- Error when deleting project, plot, or booking
- Message mentions "foreign key constraint"
- Shows error like: "Cannot delete or update a parent row"

**Solutions:**

1. **Delete child records first:**
   - To delete project: delete all its plots/bookings first
   - To delete plot: delete all its bookings first
   - System enforces data integrity

2. **Or disable foreign key temporarily:**
   ```sql
   SET FOREIGN_KEY_CHECKS = 0;
   DELETE FROM tbl_re_projects WHERE id = 1;
   SET FOREIGN_KEY_CHECKS = 1;
   ```
   - Use with caution! May create orphaned records

3. **Use cascade delete:**
   - Modify table structure to cascade deletes:
   ```sql
   ALTER TABLE tbl_re_plots 
   DROP FOREIGN KEY fk_plots_projects;
   ALTER TABLE tbl_re_plots 
   ADD CONSTRAINT fk_plots_projects 
   FOREIGN KEY (project_id) REFERENCES tbl_re_projects(id) 
   ON DELETE CASCADE;
   ```

---

## Calculation Issues

### Issue: Total price not calculating automatically

**Symptoms:**
- Enter area and rate per unit
- Total price field stays empty or shows 0
- Manual calculation needed

**Solutions:**

1. **Check JavaScript loaded:**
   - Press F12 → Console
   - Type: `typeof calculateTotal`
   - Should return "function"
   - If "undefined", JS file not loaded

2. **Verify input field IDs match:**
   - View file uses: `id="area"`, `id="rate_per_unit"`, `id="total_price"`
   - If IDs different, calculation won't work
   - Check `assets/js/real_estat.js` for expected IDs

3. **Ensure calculate function triggers:**
   - Area input should have: `onchange="calculateTotal()"`
   - Rate input should have: `onchange="calculateTotal()"`
   - If missing, add these attributes

4. **Check input values are numbers:**
   - Area must be numeric (no commas, letters)
   - Rate must be numeric
   - Calculation fails if non-numeric values

5. **Manually test in console:**
   ```javascript
   // In browser console (F12)
   var area = document.getElementById('area').value;
   var rate = document.getElementById('rate_per_unit').value;
   alert(area * rate);  // Should show calculated total
   ```

---

### Issue: Installment amounts incorrect

**Symptoms:**
- Final amount ÷ Number of installments ≠ individual amounts shown
- Rounding issues (off by $0.01-$0.10)
- Payment plan math doesn't match

**Solutions:**

1. **Check payment plan setup:**
   ```sql
   SELECT * FROM tbl_re_payment_plans;
   ```
   - `down_payment_percentage` = First payment %
   - `number_of_installments` = How many payments
   - `installment_frequency` = Time between payments (monthly, quarterly)

2. **Understand rounding:**
   - If $10,000 ÷ 3 = $3,333.33
   - Last installment = $3,333.34 (rounded up)
   - This is normal and expected

3. **Verify installment calculation logic:**
   - In `Real_estate_model.php`
   - Method: `generate_payment_installments()`
   - Check math: `amount_per_installment = final_amount / number_of_installments`
   - Round to 2 decimal places

4. **Check down payment percentage:**
   - First installment = Final Amount × (down_payment_percentage / 100)
   - Remaining installments = (Final Amount - First) ÷ Remaining Months

---

## Integration Issues

### Issue: Bookings not creating invoices

**Symptoms:**
- "Convert to Sale" button clicked
- Booking status changes to converted_to_sale
- Invoice not created in Perfex Invoices module

**Solutions:**

1. **Check Invoices module active:**
   - Go to Setup → Modules
   - Verify Invoice Manager is Activated
   - Real Estate needs Invoice module to create invoices

2. **Verify client exists in Perfex:**
   - Customer selected in booking must exist in Perfex Clients
   - Check client has email address set

3. **Check invoice creation code:**
   - In controller `Real_estat.php`
   - Method: `convert_to_sale()`
   - Should load invoices library and create invoice

4. **Check file permissions:**
   - Invoices directory must be writable
   - Check `uploads/invoices/` folder permissions

5. **Review invoice generation logic:**
   ```php
   // In Real_estate_model.php
   // verify generate_invoice() method exists and works
   $invoice = $this->db->insert('tblinvoices', $invoice_data);
   ```

---

### Issue: Activity log not showing Real Estate actions

**Symptoms:**
- Create project/plot/booking
- Don't see entries in Admin → Activity
- No record of who did what

**Solutions:**

1. **Verify activity logging in model:**
   - In `Real_estate_model.php`
   - After creating/updating records, call:
   ```php
   log_activity('Real Estate Project Added', $project_id, 'Real Estate', 'tbl_re_projects');
   ```

2. **Check activity function exists:**
   - This is Perfex core function
   - Should be available in all models
   - If not found, check application/helpers/activity_helper.php

3. **Enable activity logging in settings:**
   - Admin → Settings → General
   - Verify "Activity Log" is enabled
   - If disabled, nothing logs

---

## Performance Issues

### Issue: Page loads slowly (> 5 seconds)

**Symptoms:**
- Real Estate dashboard takes long time to load
- Plots list with 100+ plots is slow
- Bookings table lags when sorting

**Solutions:**

1. **Add database indexes:**
   ```sql
   ALTER TABLE tbl_re_plots ADD INDEX idx_project (project_id);
   ALTER TABLE tbl_re_plots ADD INDEX idx_status (status);
   ALTER TABLE tbl_re_bookings ADD INDEX idx_status (status);
   ALTER TABLE tbl_re_bookings ADD INDEX idx_customer (customer_id);
   ALTER TABLE tbl_re_booking_installments ADD INDEX idx_booking (booking_id);
   ```

2. **Limit DataTable page size:**
   - In view files
   - Change: `aLengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]]`
   - To: `aLengthMenu: [[10, 25], [10, 25]]`
   - Fewer rows per page = faster rendering

3. **Enable query caching:**
   - In model methods
   - Cache frequently called queries
   ```php
   $cache_key = 'projects_list';
   if ($cached = $this->cache->get($cache_key)) {
       return $cached;
   }
   $results = $this->db->get('tbl_re_projects')->result_array();
   $this->cache->save($cache_key, $results, 3600); // Cache 1 hour
   return $results;
   ```

4. **Reduce data fetched:**
   - Don't fetch all columns if only need some
   - Use SELECT with specific columns: `SELECT id, name, status FROM...`
   - Avoid SELECT *

5. **Archive old data:**
   - Move completed projects/bookings to archive table
   - Reduces main table size

---

## Email & Notification Issues

### Issue: No email notifications for bookings

**Symptoms:**
- Customer books a plot
- No confirmation email sent
- Email setting enabled but nothing happens

**Solutions:**

1. **Verify email settings in Perfex:**
   - Admin → Settings → Email
   - Check SMTP configured correctly
   - Test email: Click "Send Test Email"

2. **Check Real Estate email templates:**
   - Email template should exist in language file
   - Check `real_estat_lang.php` for email variables
   - Template names: booking_confirmation, payment_reminder, etc.

3. **Verify email sending in code:**
   - In `Real_estate_model.php`
   - After creating booking, should send email:
   ```php
   $this->send_booking_confirmation_email($booking_id);
   ```

4. **Check email sending method exists:**
   - May use Perfex's `send_notification()` function
   - Or Codeigniter's email library

5. **Check email logs:**
   - Perfex logs failed emails
   - Check `application/logs/` for email errors

---

## Browser-Specific Issues

### Issue: Works in Chrome, doesn't work in Firefox

**Symptoms:**
- Real Estate module works fine in Chrome
- Same page broken in Firefox
- Date picker or dropdowns not working

**Solutions:**

1. **Check JavaScript compatibility:**
   - Some JS only works in certain browsers
   - Use feature detection instead of browser detection
   - Test in console: `typeof XMLHttpRequest` (should work everywhere)

2. **Check CSS compatibility:**
   - Some CSS3 features not supported in older browsers
   - Use vendor prefixes: `-webkit-`, `-moz-`, `-ms-`
   - Test basic styling still works

3. **Check form attribute support:**
   - HTML5 date input: `<input type="date">` not supported in old Firefox
   - Use fallback: `<input type="text" class="datepicker">`

4. **Test in private/incognito window:**
   - Clears cache issues
   - Extensions may interfere in Chrome

5. **Update browser:**
   - Oldest Chrome: v1 (2008)
   - Oldest Firefox: v1 (2004)
   - Module targets modern browsers (2020+)

---

## Debugging Tips

### Enable Debug Mode

1. **In Perfex configuration:**
   - Edit `application/config/config.php`
   - Set: `$config['debug'] = 1;`
   - Shows detailed error messages

2. **Check logs:**
   - `/application/logs/log-*.php`
   - Most recent issues appear here

3. **SQL debugging:**
   - Enable query logging in `database.php`
   - Shows all SQL executed
   - Check for failed queries

4. **Browser console:**
   - Press F12
   - Check Console tab for JavaScript errors
   - Look for red error messages

5. **Network tab:**
   - Press F12 → Network tab
   - Click on action
   - Watch for 404, 500, or timeout errors
   - Click request to see response

### Get Help

**Information to provide when asking for help:**
1. Error message (exact text)
2. Browser type and version
3. Perfex version
4. PHP version
5. What action triggered error
6. Browser console errors (F12)
7. Recent PHP error log entries
8. Database state (table row counts)

---

**Last Updated**: January 2024  
**For Version**: Real Estate Module 1.0.0  
**Perfex Version**: 2.3.0+
