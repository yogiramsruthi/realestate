# Real Estate Module - Quick Reference Guide

## Quick Start

### 1. Activate the Module
1. Go to Admin → **Setup → Modules**
2. Find "Real Estate Management" in the list
3. Click **Activate**
4. Wait for "Module activated successfully" message
5. Database tables will be created automatically

### 2. Configure Permissions
1. Go to **Setup → Staff → Roles**
2. Edit the **Administrator** role (or your role)
3. Enable these checkboxes:
   - ☑ Real Estate Projects (View/Create/Edit/Delete)
   - ☑ Real Estate Plots (View/Create/Edit/Delete)
   - ☑ Real Estate Bookings (View/Create/Edit/Delete)
   - ☑ Real Estate Payments (View/Create/Edit)
4. Click **Save**
5. Log out and log back in for changes to take effect

### 3. Start Using the Module

#### Create Your First Project
1. From sidebar, click **Real Estate → Projects**
2. Click **New Project** button
3. Fill in the form:
   - **Project Code**: e.g., `DOWNTOWN-2024`
   - **Name**: e.g., `Downtown Shopping Complex`
   - **Location**: e.g., `Main Street, Downtown`
   - **Total Area**: e.g., `50000` (in sqft or sqm)
   - **Status**: Choose `in-progress` or `planning`
   - **Project Manager**: Select a staff member
   - **Start Date** & **Completion Date**: Set project timeline
4. Click **Submit**
5. ✅ Project created! You'll be redirected to the project details page

#### Add Blocks to Project
1. On the project page, scroll to **Blocks** section
2. Click **New Block**
3. Fill in:
   - **Block Name**: e.g., `Block A`
   - **Block Code**: e.g., `A`
   - **Description**: Optional details
4. Click **Submit**
5. ✅ Block added! Now you can add plots to this block

#### Create Plots
1. From sidebar, click **Real Estate → Plots**
2. Click **New Plot**
3. Fill in:
   - **Project**: Select your project
   - **Block**: Auto-populates based on project
   - **Plot Number**: e.g., `P-001`
   - **Plot Type**: residential/commercial/industrial
   - **Facing**: north/south/east/west
   - **Area**: e.g., `2500` sqft
   - **Area Unit**: sqft or sqm
   - **Dimensions**: e.g., `50x50`
   - **Rate Per Unit**: e.g., `500` (per sqft)
4. **Total Price** auto-calculates: `Area × Rate Per Unit`
5. Set **Status** to `available`
6. Click **Submit**
7. ✅ Plot created and ready for booking!

#### Create a Booking
1. From sidebar, click **Real Estate → Bookings**
2. Click **New Booking**
3. Fill in:
   - **Project**: Select your project
   - **Customer**: Choose from your Perfex clients
   - **Plot**: Auto-populates based on project; select a plot
   - **Total Amount**: Auto-fills from plot price
   - **Booking Amount**: Can be a deposit amount
   - **Discount**: Optional discount
   - **Final Amount**: Auto-calculates
   - **Payment Plan**: Choose how they'll pay (50/50, 30/70, Monthly, etc.)
4. Scroll down to see **Installments Schedule** - shows all payment due dates
5. Click **Submit**
6. ✅ Booking created! Booking code auto-generated (e.g., `BK-20240115-001`)

#### Record a Payment
1. Go to **Real Estate → Bookings**
2. Click to open a booking
3. Scroll to **Installments** section
4. Click **Record Payment** for an installment
5. Enter:
   - **Amount**: Full or partial payment
   - **Payment Date**: When they paid
   - **Payment Method**: Cash/Check/Wire/etc.
   - ☑ **Generate Invoice**: Check if you want Perfex invoice created
6. Click **Submit**
7. ✅ Payment recorded! Installment marked as paid

---

## Module Structure

```
modules/real_estat/
├── real_estat.php              # Main module file (hooks, menu, permissions)
├── controllers/
│   └── Real_estat.php          # All actions and workflows
├── models/
│   └── Real_estate_model.php   # Database operations
├── views/
│   ├── dashboard.php           # Statistics and overview
│   ├── projects/
│   │   ├── manage.php          # Projects list
│   │   └── project.php         # Add/Edit project form
│   ├── plots/
│   │   ├── manage.php          # Plots list with filters
│   │   └── plot.php            # Add/Edit plot form
│   ├── bookings/
│   │   ├── manage.php          # Bookings list
│   │   └── booking.php         # Add/Edit booking with installments
│   ├── payments/
│   │   └── manage.php          # Payment tracking
│   ├── reports/
│   │   └── project_report.php  # Project reports
│   └── settings.php            # Module configuration
├── language/
│   └── english/
│       └── real_estat_lang.php # All translations
├── assets/
│   ├── css/
│   │   └── real_estat.css      # Custom styling
│   └── js/
│       └── real_estat.js       # JavaScript functionality
├── install.php                 # Database installation
└── documentation/
    ├── README.md
    ├── SETUP_GUIDE.md
    ├── ACTIVATION_CHECKLIST.md
    ├── TESTING_CHECKLIST.md
    └── verify_installation.sql
```

---

## Database Tables (9 total)

| Table | Purpose |
|-------|---------|
| `tbl_re_projects` | Real estate projects |
| `tbl_re_blocks` | Subdivisions within projects |
| `tbl_re_plots` | Individual plot/lot listings |
| `tbl_re_bookings` | Customer bookings/reservations |
| `tbl_re_payment_plans` | Payment schedules (50/50, 30/70, Monthly, etc.) |
| `tbl_re_booking_installments` | Individual payment installments for bookings |
| `tbl_re_team_assignments` | Staff assigned to projects |
| `tbl_re_communications` | Communications with customers |
| `tbl_re_custom_fields_values` | Additional custom field values |

---

## Key Features

### Automatic Calculations
- **Plot Total Price** = Area × Rate Per Unit
- **Booking Final Amount** = Total Amount - Discount
- **Installment Amounts** = Final Amount ÷ Number of Installments

### Status Tracking
- **Plots**: Available → Booked/Reserved → Sold/Blocked
- **Bookings**: Pending → Confirmed → Converted to Sale or Cancelled
- **Installments**: Pending → Paid or Overdue

### Payment Plans
- **50/50 Plan**: 50% down, 50% on completion
- **30/70 Plan**: 30% down, 70% split into equal installments
- **Monthly Plan**: Split into monthly installments
- **Custom Plans**: Create your own with custom percentages

---

## Common Actions

### Delete a Project
⚠️ **WARNING**: This will delete all related blocks, plots, bookings, and installments!
1. Go to **Projects**
2. Click delete icon (trash) on project
3. Confirm deletion
4. All related data is deleted

### Change Booking Status
1. Open booking
2. Click dropdown in **Status** field
3. Options:
   - `pending` - New booking, awaiting confirmation
   - `confirmed` - Booking confirmed by customer
   - `converted_to_sale` - Convert booking to actual sale (create invoice)
   - `cancelled` - Booking cancelled with optional reason
4. Click **Submit**

### Generate Invoice from Booking
1. Open booking
2. Click **Convert to Sale** button (if available)
3. Creates invoice in Perfex Invoices module
4. Booking status changed to `converted_to_sale`

### Bulk Import Plots
1. Go to **Real Estate → Plots**
2. Click **Bulk Import Plots** button
3. Upload CSV file with columns: project_id, block_id, plot_number, area, rate_per_unit, etc.
4. System validates and creates all plots

### Filter by Project
1. Go to **Plots** or **Bookings**
2. Use filter dropdown to select project
3. Table updates to show only selected project's data

---

## Troubleshooting

### Module not visible in sidebar
- **Solution**: Go to Setup → Modules and click Activate next to Real Estate
- Module menu won't appear until activated

### Permission denied errors
- **Solution**: Go to Setup → Staff → Roles
  - Edit your role
  - Check all Real Estate checkboxes
  - Save and log out/back in

### Form fields not displaying
- **Solution**: Clear browser cache (Ctrl+Shift+Del) and reload
- Or: Use private/incognito browser window

### Plots not appearing in Bookings dropdown
- **Solution**: Make sure plots exist for that project and status is `available`
- Booked/Sold plots won't appear

### Calculations wrong
- **Solution**: Check "Rate Per Unit" is a number (no currency symbols)
- Check "Area" is a number

### Database error after activation
- **Solution**: Run this SQL to verify tables exist:
  ```sql
  SELECT TABLE_NAME FROM information_schema.TABLES 
  WHERE TABLE_SCHEMA = 'test_real' AND TABLE_NAME LIKE 'tbl_re_%';
  ```
- Should show 9 tables starting with `tbl_re_`

---

## Performance Tips

### For Large Projects (100+ plots)
1. Use **Bulk Import** instead of creating plots one-by-one
2. Add indexes to frequently filtered columns:
   ```sql
   ALTER TABLE tbl_re_plots ADD INDEX idx_project (project_id);
   ALTER TABLE tbl_re_plots ADD INDEX idx_status (status);
   ALTER TABLE tbl_re_bookings ADD INDEX idx_status (status);
   ```

### For Better Load Times
1. Archive old completed projects
2. Limit bookings list to last 6 months by default
3. Use project filter on Plots page

---

## Integration Points

### With Perfex Clients
- Bookings linked to Perfex clients
- Client name, email, phone auto-populated

### With Perfex Staff
- Project managers selected from staff list
- Team members assigned to projects
- Activity logged under staff name

### With Perfex Invoices
- "Convert to Sale" creates invoice in Perfex
- Installment payments can generate invoices
- Invoice amounts auto-calculated from payment plans

### With Perfex Activity Log
- All actions logged: project created, plot added, booking created, payment recorded
- User attribution (who created/edited each record)

---

## API Endpoints (for custom integration)

```
GET    /admin/real_estat/                           # Dashboard
GET    /admin/real_estat/projects                   # Project list
GET    /admin/real_estat/project/{id}               # Edit project
POST   /admin/real_estat/project                    # Create project
POST   /admin/real_estat/delete_project/{id}        # Delete project

GET    /admin/real_estat/plots                      # Plot list
GET    /admin/real_estat/plot/{id}                  # Edit plot
POST   /admin/real_estat/plot                       # Create plot
POST   /admin/real_estat/delete_plot/{id}           # Delete plot

GET    /admin/real_estat/bookings                   # Booking list
GET    /admin/real_estat/booking/{id}               # Edit booking
POST   /admin/real_estat/booking                    # Create booking
POST   /admin/real_estat/cancel_booking/{id}        # Cancel booking
POST   /admin/real_estat/convert_to_sale/{id}       # Convert to invoice

GET    /admin/real_estat/get_blocks_by_project      # AJAX: Get blocks
GET    /admin/real_estat/get_available_plots        # AJAX: Get available plots

POST   /admin/real_estat/record_payment             # Record payment for installment
GET    /admin/real_estat/reports/project/{id}       # Generate project report
```

---

## Support

For issues or feature requests:
1. Check **TESTING_CHECKLIST.md** for comprehensive test cases
2. Review **verify_installation.sql** to validate database
3. Check browser console for JavaScript errors (F12)
4. Check Perfex logs at `/logs/`

---

**Last Updated**: January 2024  
**Module Version**: 1.0.0  
**Perfex Version**: 2.3.0+  
**PHP Version**: 7.2+
