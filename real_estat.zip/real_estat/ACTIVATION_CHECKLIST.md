# ✅ Real Estate Module - Activation Checklist

## Browser Opened: http://localhost/test_real/admin/modules

Follow these steps in the browser that just opened:

---

## 🔐 STEP 1: Login to Perfex Admin

If not already logged in:
- **Email:** Check your admin credentials
- **Password:** Your admin password

---

## 📦 STEP 2: Activate the Module

You should now be on the Modules page.

**Look for:** "Real Estate Management"

**Module Details:**
- **Name:** Real Estate Management
- **Description:** Complete Real Estate Management System for managing projects, plots, bookings, and sales
- **Version:** 1.0.0
- **Requires:** Perfex CRM 2.3.0+

**Click:** The **"Activate"** button (usually green/blue)

**Wait for:** Success message "Module activated successfully"

**What happens during activation:**
1. ✅ 9 database tables are created (tbl_re_*)
2. ✅ 4 default payment plans are inserted
3. ✅ Module hooks are registered
4. ✅ Menu items are prepared (but need permissions to show)

---

## 🔑 STEP 3: Configure Permissions

### A. Navigate to Roles
1. Click **Setup** (gear icon) in left sidebar
2. Click **Staff**
3. Click **Roles**

### B. Edit Administrator Role
1. Click on **Administrator** role (or your current role)
2. Scroll down to find **Real Estate** section

### C. Enable All Permissions
You'll see 4 sections - Enable ALL checkboxes:

**📁 Real Estate Projects**
- ☑️ View (View - Global)
- ☑️ Create
- ☑️ Edit
- ☑️ Delete

**📐 Real Estate Plots**
- ☑️ View (View - Global)
- ☑️ Create
- ☑️ Edit
- ☑️ Delete

**📋 Real Estate Bookings**
- ☑️ View (View - Global)
- ☑️ Create
- ☑️ Edit
- ☑️ Delete

**💰 Real Estate Payments**
- ☑️ View (View - Global)
- ☑️ Create
- ☑️ Edit
- ☑️ Delete

### D. Save and Refresh
1. Click **Save** button at bottom
2. **Logout** from admin panel
3. **Login again** to apply permissions

---

## 🎉 STEP 4: Verify Activation

After logging back in, check the **left sidebar**.

You should now see a new menu item:

**🏢 Real Estate** (with building/home icon)

Click it to expand and see:
- Projects
- Plots
- Bookings
- Payments
- Reports
- Settings

---

## 🚀 STEP 5: Create Your First Project

### Quick Test:

1. **Click:** Real Estate → Projects
2. **Click:** "New Project" button
3. **Fill in:**
   - Project Code: `TEST001`
   - Project Name: `Test Project`
   - Location: `Test Location`
   - Status: `Active`
4. **Click:** Submit

✅ **Success!** You should see the project created.

---

## 📊 Database Verification (Optional)

Open phpMyAdmin: http://localhost/phpmyadmin

Select database: `test_real`

Check these tables exist:
```
✓ tbl_re_projects
✓ tbl_re_blocks
✓ tbl_re_plots
✓ tbl_re_bookings
✓ tbl_re_payment_plans (should have 4 rows)
✓ tbl_re_booking_installments
✓ tbl_re_team_assignments
✓ tbl_re_communications
✓ tbl_re_custom_fields_values
```

---

## ❌ Troubleshooting

### Module Not Showing in List
- ✅ Check file exists: `modules/real_estat/real_estat.php`
- ✅ File permissions: 644 for files, 755 for folders
- ✅ Clear browser cache (Ctrl + F5)

### Activation Button Disabled/Missing
- ✅ Check if already activated
- ✅ Verify PHP version (7.2+)
- ✅ Check database connection

### Permission Sections Not Appearing
- ✅ Module must be activated first
- ✅ Refresh the roles page
- ✅ Try editing a different role

### Menu Not Appearing After Activation
- ✅ Enable permissions (Step 3)
- ✅ Logout and login again
- ✅ Clear browser cache

### Tables Not Created
- ✅ Check database user has CREATE TABLE privilege
- ✅ Check `application/logs/` for PHP errors
- ✅ Manually run SQL from `verify_installation.sql`

---

## 📞 Quick Reference

**Module Location:** `c:\xampp\htdocs\test_real\modules\real_estat\`

**Documentation:** `README.md`

**Setup Guide:** `SETUP_GUIDE.md`

**Verify SQL:** `verify_installation.sql`

**Admin URL:** http://localhost/test_real/admin

**Modules URL:** http://localhost/test_real/admin/modules

---

## ✨ What's Next?

After successful activation:

1. ✅ Create projects
2. ✅ Add plots (individual or bulk import)
3. ✅ Create bookings for customers
4. ✅ Configure payment plans
5. ✅ Record payments
6. ✅ Generate reports

**Full workflow documentation:** See `README.md`

---

## 🎯 Module Features Activated

✅ Project Management
✅ Plot Management with Bulk Import
✅ Booking System with Auto Code Generation
✅ Payment Plans & Installment Tracking
✅ Team Assignment
✅ Communication Logging
✅ Integration with Perfex Invoices
✅ Comprehensive Reports
✅ Role-based Permissions
✅ Activity Logging

---

**Current Status:** Ready for activation in browser!

**Next Action:** Click "Activate" button in the browser window that opened.
