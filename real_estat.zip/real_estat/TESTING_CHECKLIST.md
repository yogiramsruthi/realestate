# Real Estate Module - Testing Checklist

## Pre-Testing Setup
- [ ] Module activated in Perfex Admin → Setup → Modules → Real Estate Management
- [ ] Staff role permissions configured (Admin role has all checkboxes enabled)
- [ ] Database tables created successfully (run verify_installation.sql to check)
- [ ] Module menu visible in Admin Dashboard left sidebar

## Module Access Testing

### 1. Dashboard Access
- [ ] Navigate to Admin → Real Estate (or click Real Estate from sidebar)
- [ ] Dashboard loads without errors
- [ ] Statistics cards display:
  - [ ] Total Projects
  - [ ] Total Plots
  - [ ] Total Bookings
  - [ ] Total Revenue
- [ ] Recent Bookings table displays (if any exist)
- [ ] Overdue Installments table displays (if any exist)

### 2. Projects Management

#### 2.1 Projects List View
- [ ] Navigate to Real Estate → Projects
- [ ] Projects table loads with DataTable
- [ ] Create New Project button visible and clickable
- [ ] Column headers display: Plot Number, Project Name, Block Name, Area, Type, Price, Status, Options

#### 2.2 Create New Project
- [ ] Click "New Project" button
- [ ] All form fields display correctly:
  - [ ] Project Code (text input)
  - [ ] Project Name (text input)
  - [ ] Location (text input)
  - [ ] Description (textarea)
  - [ ] Total Area (number input)
  - [ ] Status (dropdown: planning/in-progress/completed)
  - [ ] Project Manager (staff dropdown)
  - [ ] Start Date (date picker)
  - [ ] Completion Date (date picker)
- [ ] Fill form with test data:
  - [ ] Code: PROJ001
  - [ ] Name: Test Real Estate Project
  - [ ] Location: Downtown
  - [ ] Description: Testing project for module
  - [ ] Total Area: 10000
  - [ ] Status: in-progress
  - [ ] Select a project manager
  - [ ] Set dates
- [ ] Click Submit
- [ ] Success message appears: "Project added successfully"
- [ ] Redirected to project edit page
- [ ] All entered data displays in form

#### 2.3 Edit Project
- [ ] From projects list, click edit icon on test project
- [ ] Form loads with existing data
- [ ] Modify a field (e.g., Description)
- [ ] Click Submit
- [ ] Success message appears: "Project updated successfully"
- [ ] Modified data persists

#### 2.4 Project Detail View
- [ ] On project edit page, scroll down to see:
  - [ ] Project Statistics section (plots count, bookings count, revenue)
  - [ ] Blocks section (list of project blocks)
  - [ ] Plots section (list of project plots)
  - [ ] Team Assignments section (team members assigned to project)

### 3. Blocks Management

#### 3.1 Add Block to Project
- [ ] On project page, click "New Block" in Blocks section
- [ ] Modal dialog opens with form:
  - [ ] Block Name (text input)
  - [ ] Block Code (text input)
  - [ ] Description (textarea)
- [ ] Fill test data:
  - [ ] Name: Block A
  - [ ] Code: BLK001
  - [ ] Description: First block
- [ ] Click Submit
- [ ] Block appears in Blocks list on project page

#### 3.2 Edit Block
- [ ] Click edit icon on block in Blocks section
- [ ] Modal opens with block data
- [ ] Modify description
- [ ] Click Submit
- [ ] Changes persist

### 4. Plots Management

#### 4.1 Plots List View
- [ ] Navigate to Real Estate → Plots
- [ ] Plots table loads with DataTable
- [ ] Create New Plot button visible
- [ ] Project filter dropdown displays and is functional
- [ ] Column headers display: Plot Number, Project, Block, Area, Type, Price, Status, Options

#### 4.2 Create New Plot
- [ ] Click "New Plot" button
- [ ] All form fields display:
  - [ ] Project (dropdown - should dynamically populate)
  - [ ] Block (dropdown - populates based on selected project)
  - [ ] Plot Number (text input)
  - [ ] Plot Type (dropdown: residential/commercial/industrial)
  - [ ] Facing (dropdown: north/south/east/west/corner)
  - [ ] Area (number input)
  - [ ] Area Unit (dropdown: sqft/sqm)
  - [ ] Dimensions (text input, e.g., 100x150)
  - [ ] Rate Per Unit (number input)
  - [ ] Total Price (auto-calculated, read-only)
  - [ ] Status (dropdown)
  - [ ] Description (textarea)
- [ ] Select project (Test Real Estate Project)
- [ ] Verify Block dropdown populates (should show Block A)
- [ ] Fill plot data:
  - [ ] Plot Number: P001
  - [ ] Plot Type: residential
  - [ ] Facing: north
  - [ ] Area: 2500
  - [ ] Area Unit: sqft
  - [ ] Dimensions: 50x50
  - [ ] Rate Per Unit: 500
- [ ] Verify Total Price auto-calculates: 2500 * 500 = 1,250,000
- [ ] Click Submit
- [ ] Success message appears
- [ ] Plot appears in list

#### 4.3 Edit Plot
- [ ] From plots list, click edit on test plot
- [ ] All fields load correctly
- [ ] Modify Rate Per Unit
- [ ] Verify Total Price updates
- [ ] Submit changes
- [ ] Changes persist

#### 4.4 Filter Plots by Project
- [ ] In Plots list, select "Test Real Estate Project" from filter
- [ ] Table refreshes and shows only plots from that project
- [ ] Clear filter and verify all plots show

### 5. Bookings Management

#### 5.1 Bookings List View
- [ ] Navigate to Real Estate → Bookings
- [ ] Bookings table loads with DataTable
- [ ] Create New Booking button visible
- [ ] Status filter visible and functional
- [ ] Column headers display: Booking Code, Plot, Customer, Booking Date, Amount, Status, Options

#### 5.2 Create New Booking
- [ ] Click "New Booking" button
- [ ] All form fields display:
  - [ ] Project (dropdown)
  - [ ] Customer (dropdown - should show Perfex clients)
  - [ ] Plot (dropdown - populated based on project)
  - [ ] Booking Date (date picker)
  - [ ] Booking Amount (number input)
  - [ ] Total Amount (auto-calculated from plot price)
  - [ ] Discount (number input)
  - [ ] Final Amount (auto-calculated: total - discount)
  - [ ] Payment Plan (dropdown)
  - [ ] Notes (textarea)
- [ ] Select Project (Test Real Estate Project)
- [ ] Verify Plot dropdown populates (should show P001)
- [ ] Select customer from dropdown
- [ ] Select plot (P001)
- [ ] Verify Total Amount auto-populates from plot price
- [ ] Enter Booking Amount and Discount
- [ ] Verify Final Amount auto-calculates
- [ ] Select Payment Plan (e.g., 50/50, 30/70, Monthly)
- [ ] In sidebar, verify installments display:
  - [ ] Each installment shows due date, amount, and status
  - [ ] Number and amounts match selected payment plan
- [ ] Click Submit
- [ ] Success message appears
- [ ] Booking code auto-generated (e.g., BK-20240115-001)
- [ ] Status defaults to "pending"

#### 5.3 Edit Booking
- [ ] From bookings list, click edit on booking
- [ ] All fields load with data
- [ ] Sidebar shows installment schedule
- [ ] Modify a field
- [ ] Submit
- [ ] Changes persist

#### 5.4 Payment Plan Selection
- [ ] In booking form, test different payment plans:
  - [ ] 50% Down Payment, 50% on Completion
  - [ ] 30% Down, 70% Equal Installments (e.g., 3 months)
  - [ ] Monthly Installments
- [ ] Verify installment schedule updates correctly for each plan

### 6. Payments Management

#### 6.1 Payments List View
- [ ] Navigate to Real Estate → Payments
- [ ] Payments table loads
- [ ] Can see all recorded payments (if any)
- [ ] Column headers display: Booking, Plot, Amount, Date, Invoice, Status

#### 6.2 Record Payment
- [ ] From Bookings list, open a booking with pending installments
- [ ] In installments table, click "Record Payment" for an installment
- [ ] Payment modal opens:
  - [ ] Shows installment amount
  - [ ] Amount field (can be full or partial)
  - [ ] Payment Date (date picker)
  - [ ] Payment Method (dropdown)
  - [ ] Notes (textarea)
  - [ ] Generate Invoice checkbox
- [ ] Fill payment data
- [ ] Check "Generate Invoice" if desired
- [ ] Click Submit
- [ ] Payment recorded
- [ ] Installment status changes to "paid"
- [ ] Invoice created (if checkbox was enabled)

### 7. Reports

#### 7.1 Project Report
- [ ] Navigate to Real Estate → Reports
- [ ] Click "Project Report" for test project
- [ ] Report displays:
  - [ ] Project details
  - [ ] Total plots and status breakdown
  - [ ] Total bookings and revenue
  - [ ] Team members assigned
  - [ ] Recent activities/communications

#### 7.2 Generate Reports
- [ ] Test export to PDF (if available)
- [ ] Test export to Excel (if available)

### 8. Settings

#### 8.1 Access Settings
- [ ] Navigate to Real Estate → Settings
- [ ] Settings form displays with options for:
  - [ ] Default currency
  - [ ] Number format
  - [ ] Default payment terms
  - [ ] Email notifications for bookings
  - [ ] Other module-specific settings

#### 8.2 Save Settings
- [ ] Modify a setting
- [ ] Click Save
- [ ] Success message appears
- [ ] Setting persists after reload

### 9. Permissions Testing

#### 9.1 Test Different User Roles
- [ ] Create test staff member or use existing one
- [ ] Assign them to a role with limited Real Estate permissions
- [ ] Test as that user:
  - [ ] Verify they can only access permitted sections
  - [ ] Verify create/edit/delete buttons hidden for restricted actions
  - [ ] Verify access_denied message shows for unauthorized actions

#### 9.2 Permission Groups
- [ ] Verify these permissions exist in Setup → Roles:
  - [ ] real_estate_projects (view, create, edit, delete)
  - [ ] real_estate_plots (view, create, edit, delete)
  - [ ] real_estate_bookings (view, create, edit, delete)
  - [ ] real_estate_payments (view, create, edit)

### 10. Data Validation

#### 10.1 Form Validation
- [ ] Try submitting forms with required fields empty
- [ ] Verify error messages appear
- [ ] Try entering invalid data:
  - [ ] Non-numeric in numeric fields
  - [ ] Duplicate project code
  - [ ] Invalid dates
- [ ] Verify validation messages show appropriately

#### 10.2 Business Logic Validation
- [ ] Try creating booking for already-sold plot
- [ ] Verify status restrictions (can't convert cancelled booking to sale)
- [ ] Try recording payment greater than installment amount (should allow partial or warn)

### 11. Database Verification

#### 11.1 Check Database Tables
Run this SQL to verify all tables exist and have data:

```sql
-- Check all tables exist
SELECT TABLE_NAME FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = 'test_real' AND TABLE_NAME LIKE 'tbl_re_%';

-- Check record counts
SELECT 'Projects' as entity, COUNT(*) as count FROM tbl_re_projects
UNION ALL
SELECT 'Blocks', COUNT(*) FROM tbl_re_blocks
UNION ALL
SELECT 'Plots', COUNT(*) FROM tbl_re_plots
UNION ALL
SELECT 'Bookings', COUNT(*) FROM tbl_re_bookings
UNION ALL
SELECT 'Payment Plans', COUNT(*) FROM tbl_re_payment_plans
UNION ALL
SELECT 'Bookings Installments', COUNT(*) FROM tbl_re_booking_installments
UNION ALL
SELECT 'Team Assignments', COUNT(*) FROM tbl_re_team_assignments;
```

#### 11.2 Check Data Integrity
- [ ] All foreign keys resolve correctly
- [ ] No orphaned records
- [ ] Timestamps are correct

### 12. Performance Testing

#### 12.1 Page Load Times
- [ ] Dashboard loads in < 2 seconds
- [ ] Projects list loads in < 2 seconds with DataTable
- [ ] Plots list loads in < 2 seconds with filters
- [ ] Bookings list loads in < 2 seconds

#### 12.2 Large Dataset Testing
- [ ] Create 50+ plots
- [ ] Create 20+ bookings
- [ ] Verify tables still filter/sort quickly
- [ ] Verify no browser lag

### 13. Integration Testing

#### 13.1 Perfex Integration
- [ ] Bookings use real Perfex clients
- [ ] Generated invoices appear in Perfex Invoices module
- [ ] Activity logged in Perfex Activity module
- [ ] Files uploaded to booking appear in Perfex file system

#### 13.2 Cross-Module Features
- [ ] Can link bookings to existing Perfex clients
- [ ] Can generate invoices that appear in Perfex
- [ ] Can assign Perfex staff to projects

### 14. Browser Compatibility

Test in:
- [ ] Chrome/Chromium
- [ ] Firefox
- [ ] Edge
- [ ] Mobile browser (iPhone/Android)

Verify:
- [ ] Forms display correctly
- [ ] Dropdowns work
- [ ] Date pickers work
- [ ] Tables responsive
- [ ] No console errors

### 15. Error Handling

#### 15.1 Graceful Error Handling
- [ ] Delete project with related plots/bookings
- [ ] Verify no database errors
- [ ] Cascade deletes work correctly
- [ ] Proper error messages shown to user

#### 15.2 Missing Data Scenarios
- [ ] Display plot with deleted project (check handling)
- [ ] Try to access deleted project directly (show 404)
- [ ] Try to access deleted booking directly (show 404)

### 16. Module Deactivation/Reactivation

- [ ] Deactivate module from Setup → Modules
- [ ] Verify module removed from menu
- [ ] Verify database tables persist (not deleted)
- [ ] Reactivate module
- [ ] Verify all data still exists
- [ ] Verify module functions normally

## Results Summary

Date Tested: _______________
Tester Name: _______________
Overall Status: ☐ Pass  ☐ Fail

Issues Found:
1. _______________________________________________
2. _______________________________________________
3. _______________________________________________

Notes:
_________________________________________________
_________________________________________________
_________________________________________________

**Module Status: READY FOR PRODUCTION** ☐ YES ☐ NO
