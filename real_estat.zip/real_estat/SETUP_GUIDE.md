# Real Estate Module - Quick Setup Guide

## Step 1: Activate the Module

1. **Access Perfex Admin Panel**
   - Open browser: http://localhost/test_real/admin
   - Login with your credentials:
     - Email: admin@example.com (or your admin email)
     - Password: (your admin password)

2. **Navigate to Modules**
   - Click on `Setup` (gear icon) in the sidebar
   - Click on `Modules`
   - You should see "Real Estate Management" in the list

3. **Activate the Module**
   - Find "Real Estate Management v1.0.0"
   - Click the `Activate` button
   - Wait for activation to complete
   - Database tables will be created automatically

## Step 2: Configure Permissions

1. **Go to Roles Settings**
   - Click `Setup` → `Staff` → `Roles`
   - Click on `Administrator` role (or the role you want to configure)

2. **Enable Real Estate Permissions**
   - Scroll down to find "Real Estate" section
   - You'll see four permission groups:
     
     ✅ **Real Estate Projects**
     - [x] View
     - [x] Create
     - [x] Edit
     - [x] Delete
     
     ✅ **Real Estate Plots**
     - [x] View
     - [x] Create
     - [x] Edit
     - [x] Delete
     
     ✅ **Real Estate Bookings**
     - [x] View
     - [x] Create
     - [x] Edit
     - [x] Delete
     
     ✅ **Real Estate Payments**
     - [x] View
     - [x] Create
     - [x] Edit
     - [x] Delete

3. **Save Permissions**
   - Click `Save` button at the bottom
   - Logout and login again to apply permissions

## Step 3: Access the Module

After activation and permission setup, you'll see a new menu item in the sidebar:

🏢 **Real Estate** (with building icon)
   - Projects
   - Plots
   - Bookings
   - Payments
   - Reports
   - Settings

## Quick Start - Create Your First Project

1. **Click Real Estate → Projects**
2. **Click "New Project" button**
3. **Fill in the form:**
   - Project Code: `PROJ001`
   - Project Name: `Green Valley Residency`
   - Location: `123 Main Street, City`
   - Total Area: `50000` (sq ft)
   - Status: `Active`
   - Start Date: Select today's date
   - Click `Submit`

4. **Add Some Plots**
   - From the project page, click "New Plot"
   - Plot Number: `A-101`
   - Area: `1200`
   - Rate per Unit: `100`
   - Status: `Available`
   - Click `Submit`

5. **Create a Test Booking**
   - Go to Real Estate → Bookings
   - Click "New Booking"
   - Select Customer (you may need to create a customer first)
   - Select Project and Plot
   - Enter booking details
   - Select Payment Plan
   - Click `Submit`

## Default Payment Plans

The module comes with 4 pre-configured payment plans:

1. **One Time Payment** - 100% upfront
2. **30-70 Plan** - 30% down, 70% in 12 monthly installments
3. **20-80 Plan** - 20% down, 80% in 24 monthly installments
4. **Quarterly Plan** - 10% down, rest in 12 quarterly installments

You can add more custom payment plans from:
Real Estate → Payments → Payment Plans

## Troubleshooting

### Module Not Showing
- Clear browser cache (Ctrl + F5)
- Check `modules/real_estat/real_estat.php` exists
- Check file permissions (folders: 755, files: 644)

### Activation Failed
- Check database connection in `application/config/database.php`
- Ensure database user has CREATE TABLE permissions
- Check PHP error log: `application/logs/`

### Permission Issues
- Ensure you're logged in as Administrator
- Enable all Real Estate permissions in Setup → Staff → Roles
- Logout and login again

### Tables Not Created
The following tables should be created on activation:
- tbl_re_projects
- tbl_re_blocks
- tbl_re_plots
- tbl_re_bookings
- tbl_re_payment_plans
- tbl_re_booking_installments
- tbl_re_team_assignments
- tbl_re_communications
- tbl_re_custom_fields_values

Check them in your database:
```sql
SHOW TABLES LIKE 'tbl_re_%';
```

## Manual Activation (If Needed)

If automatic activation fails, run this SQL manually:

```sql
USE test_real;
SOURCE c:/xampp/htdocs/test_real/modules/real_estat/install.php;
```

## Module Configuration

Go to Real Estate → Settings to configure:
- Booking code prefix
- Default booking validity days
- Auto-generate invoices
- Email notifications
- Display preferences

## Need Help?

Check the complete documentation:
`modules/real_estat/README.md`

## Module Information

- **Version:** 1.0.0
- **Compatible with:** Perfex CRM 2.3.0+
- **Database:** MySQL 5.6+ / MariaDB 10.0+
- **PHP:** 7.2+

---

🎉 **Ready to Go!**

Your Real Estate Management module is now installed and configured.
Start by creating your first project and adding some plots!
