# Real Estate Module - Visual Reference Guide

## 🎨 Module Screenshots & UI Guide

> **Note**: This is a text-based visual reference. For actual screenshots, activate the module and navigate to each page.

---

## 📍 Navigation Menu

### Sidebar Menu Structure
```
┌─────────────────────────────────
│ 📍 Real Estate
│   ├─ Dashboard
│   ├─ 📋 Projects
│   │  ├─ All Projects
│   │  └─ New Project
│   ├─ 📐 Plots
│   │  ├─ All Plots
│   │  └─ New Plot
│   ├─ 📅 Bookings
│   │  ├─ All Bookings
│   │  └─ New Booking
│   ├─ 💰 Payments
│   ├─ 📊 Reports
│   │  └─ Project Reports
│   └─ ⚙️ Settings
└─────────────────────────────────
```

---

## 🏠 Dashboard Page

### Layout
```
┌──────────────────────────────────────────────┐
│            REAL ESTATE DASHBOARD              │
├──────────────────────────────────────────────┤
│  ┌────────┐  ┌────────┐  ┌────────┐  ┌─────┐ │
│  │Projects│  │  Plots │  │Bookings│  │ $ $ │ │
│  │   12   │  │   48   │  │   8    │  │5.2M │ │
│  └────────┘  └────────┘  └────────┘  └─────┘ │
│                                               │
│  Recent Bookings                              │
│  ┌─────────────────────────────────────────┐ │
│  │ Booking Code │ Plot │ Customer │ Amount│ │
│  │ BK-001-2024  │ P-01 │ ABC Corp │$1.2M │ │
│  │ BK-002-2024  │ P-02 │ XYZ Ltd  │$950K │ │
│  │ BK-003-2024  │ P-03 │ Dev Inc  │$2.1M │ │
│  └─────────────────────────────────────────┘ │
│                                               │
│  Overdue Installments                         │
│  ┌─────────────────────────────────────────┐ │
│  │ Booking │ Installment │ Due Date │ Amt │ │
│  │ BK-001  │     2/5     │ Jan 15   │500K │ │
│  │ BK-002  │     1/3     │ Jan 10   │300K │ │
│  └─────────────────────────────────────────┘ │
└──────────────────────────────────────────────┘
```

### Statistics Cards
```
┌─────────────────────────────┐
│     TOTAL PROJECTS          │
│            12               │  Green card with number
│  Last 30 days: +3           │  Includes trend
└─────────────────────────────┘

Similar for:
- Total Plots (48)
- Total Bookings (8)
- Revenue (₹5.2M)
```

---

## 📋 Projects Management

### Projects List View
```
┌──────────────────────────────────────────────────────────┐
│ Real Estate > Projects                                   │
├──────────────────────────────────────────────────────────┤
│ [+ New Project]  [+ Bulk Import]        [🔍 Search] [⚙️] │
├──────────────────────────────────────────────────────────┤
│ Project Code │ Name │ Location │ Status │ Manager │ Opts │
│──────────────┼──────┼──────────┼────────┼─────────┼──────│
│ PROJ-001     │Down… │Main St   │ In Pro │ John    │ ✏️ 🗑 │
│ PROJ-002     │Resi… │Park Ave  │ Plan   │ Sarah   │ ✏️ 🗑 │
│ PROJ-003     │Comm… │Bus Center│Complet │ Mike    │ ✏️ 🗑 │
│              │      │          │        │         │      │
└──────────────────────────────────────────────────────────┘

Features:
- DataTable with sorting, filtering, pagination
- Search by code, name, location
- Color-coded status (green=completed, yellow=in-progress, gray=planning)
- Edit (pencil icon) and Delete (trash icon) buttons
```

### Create/Edit Project Form
```
┌────────────────────────────────────────────┐
│ New Project                                │
├────────────────────────────────────────────┤
│                                            │
│ Project Code *         │ PROJ-001        │ │
│                        └────────────────┘ │
│                                            │
│ Project Name *         │ Downtown Center │ │
│                        └────────────────┘ │
│                                            │
│ Location               │ Main Street     │ │
│                        └────────────────┘ │
│                                            │
│ Description                                │
│ ┌──────────────────────────────────────┐  │
│ │ Modern shopping center with retail   │  │
│ │ and office spaces...                 │  │
│ └──────────────────────────────────────┘  │
│                                            │
│ Total Area             │ 50000         │ │
│ (in sqft/sqm)          └────────────────┘ │
│                                            │
│ Status                 │ [In Progress ▼]│ │
│                        └────────────────┘ │
│                                            │
│ Project Manager        │ [John Smith ▼]  │ │
│                        └────────────────┘ │
│                                            │
│ Start Date             │ 2024-01-01    │ │
│                        └────────────────┘ │
│                                            │
│ Completion Date        │ 2024-12-31    │ │
│                        └────────────────┘ │
│                                            │
│                    [Submit] [Cancel]       │
└────────────────────────────────────────────┘

Additional sections (when editing):
- Project Statistics (blocks: 3, plots: 48, bookings: 8)
- Blocks List (with "New Block" button)
- Plots List (preview of project plots)
- Team Assignments (staff assigned to project)
```

---

## 📐 Plots Management

### Plots List View
```
┌─────────────────────────────────────────────────────┐
│ Real Estate > Plots                                 │
├─────────────────────────────────────────────────────┤
│ [+ New Plot] [📤 Bulk Import]  [Filter: All ▼] 🔍  │
├─────────────────────────────────────────────────────┤
│ Number│Project│Block│Area │Type│Price│Status│ Opts │
│───────┼───────┼─────┼─────┼────┼─────┼──────┼──────│
│ P-001 │Down… │Block A│2500 │Res │$1.2M│Avail │✏️ 🗑 │
│ P-002 │Down… │Block A│3000 │Res │$1.5M│Booked│✏️ 🗑 │
│ P-003 │Down… │Block B│5000 │Com │$3.0M│ Sold │✏️ 🗑 │
│       │      │      │     │    │     │      │      │
└─────────────────────────────────────────────────────┘

Features:
- Filter dropdown (All Projects, Project 1, Project 2, etc.)
- Status badges with colors:
  🟢 Available (green)
  🟡 Booked (yellow)
  🔵 Sold (blue)
  ⚪ Reserved (gray)
  🔴 Blocked (red)
```

### Create/Edit Plot Form
```
┌──────────────────────────────────────────┐
│ New Plot                                 │
├──────────────────────────────────────────┤
│                                          │
│ Project *          │ [Downtown Center ▼]│
│                    └────────────────────┘
│                                          │
│ Block *            │ [Block A ▼]        │ (auto-populate based on project)
│                    └────────────────────┘
│                                          │
│ Plot Number *      │ P-001             │
│                    └────────────────────┘
│                                          │
│ Plot Type          │ [Residential ▼]    │
│                    └────────────────────┘
│                                          │
│ Facing             │ [North ▼]          │
│                    └────────────────────┘
│                                          │
│ Area *             │ 2500              │
│                    └────────────────────┘
│                                          │
│ Area Unit          │ [sqft ▼]           │
│                    └────────────────────┘
│                                          │
│ Dimensions         │ 50x50              │
│                    └────────────────────┘
│                                          │
│ Rate Per Unit *    │ 500                │ (₹/sqft)
│                    └────────────────────┘
│                                          │
│ Total Price        │ 1,250,000          │ (Read-only, auto-calculated)
│ (Area × Rate)      └────────────────────┘
│                                          │
│ Status             │ [Available ▼]      │
│                    └────────────────────┘
│                                          │
│ Description                              │
│ ┌──────────────────────────────────────┐ │
│ │ Corner plot with excellent access    │ │
│ │ Near main entrance...                │ │
│ └──────────────────────────────────────┘ │
│                                          │
│                [Submit] [Cancel]         │
└──────────────────────────────────────────┘

JavaScript Features:
✓ calculateTotal() - Updates on area/rate change
✓ Block dropdown auto-populates based on project
✓ Validation on submit
```

---

## 📅 Bookings Management

### Bookings List View
```
┌────────────────────────────────────────────────┐
│ Real Estate > Bookings                         │
├────────────────────────────────────────────────┤
│ [+ New Booking] [All] [Pending] [Confirmed]   │
│                [Converted] [Cancelled]        │
├────────────────────────────────────────────────┤
│Code │Plot│Customer│Date │Amount│Status│ Opts │
│─────┼────┼────────┼─────┼──────┼──────┼──────│
│BK-01│P-01│ABC Corp│Jan1 │$1.2M │✓ Con│✏️ 🗑 │
│BK-02│P-02│XYZ Ltd │Jan3 │$950K │⏳Pend│✏️ 🗑 │
│BK-03│P-03│Dev Inc │Jan5 │$2.1M │✓ Conv│✏️ 🗑 │
│     │    │        │     │      │      │      │
└────────────────────────────────────────────────┘

Status Buttons:
- [All] - Show all bookings
- [Pending] - Awaiting confirmation (⏳ gray)
- [Confirmed] - Confirmed bookings (✓ blue)
- [Converted] - Converted to sale (✓✓ green)
- [Cancelled] - Cancelled bookings (✗ red)
```

### Create/Edit Booking Form
```
┌─────────────────────────────────────┬─────────────────────┐
│ New Booking                         │  Plot Details       │
├─────────────────────────────────────┼─────────────────────┤
│                                     │                     │
│ Project *          │ [Downtown ▼]   │ Plot Number: P-001  │
│                    └──────────────┘  │ Area: 2,500 sqft    │
│                                     │ Type: Residential   │
│ Customer *         │ [ABC Corp ▼]   │ Rate: ₹500/sqft     │
│                    └──────────────┘  │ ─────────────────   │
│                                     │ Price: ₹1,250,000   │
│ Plot *             │ [P-001 ▼]      │                     │
│                    └──────────────┘  │ Installments       │
│ (auto-populates based on project)   │ ┌──────────────────┤
│                                     │ │ Due   │ Amount    │
│ Booking Date *     │ 2024-01-10     │ │─────┼──────────│
│                    └──────────────┘  │ │ Now │ ₹375,000 │
│                                     │ │ 3mo │ ₹875,000 │
│ Booking Amount     │ 1,250,000       │ └──────────────────┤
│                    └──────────────┘  │                     │
│                                     │ [Record Payment]    │
│ Total Amount       │ 1,250,000       │                     │
│ (from plot)        └──────────────┘  │ [Cancel Booking]    │
│                                     │                     │
│ Discount           │ 0               │ [Convert to Sale]   │
│                    └──────────────┘  │                     │
│                                     │                     │
│ Final Amount       │ 1,250,000       │                     │
│ (Total - Disc)     └──────────────┘  │                     │
│                                     │                     │
│ Payment Plan *     │ [30/70 in 3mo ▼]│                    │
│                    └──────────────┘  │                     │
│                                     │                     │
│ Notes                                │                     │
│ ┌──────────────────────────────────┐ │                     │
│ │ Customer wants monthly instead    │ │                     │
│ └──────────────────────────────────┘ │                     │
│                                     │                     │
│          [Submit] [Cancel]          │                     │
└─────────────────────────────────────┴─────────────────────┘

JavaScript Features:
✓ loadPlots() - Get available plots for project
✓ updatePlotPrice() - Fetch plot details
✓ calculateFinalAmount() - Recalculate on discount change
✓ Installment table updates when payment plan changes
```

---

## 💰 Payments Management

### Payments List View
```
┌────────────────────────────────────────────────┐
│ Real Estate > Payments                         │
├────────────────────────────────────────────────┤
│ [🔍 Search]  [📅 Date Range]  [📊 Export]     │
├────────────────────────────────────────────────┤
│Booking│Installment│Amount │Date│Method │Status│
│───────┼───────────┼───────┼────┼───────┼──────│
│BK-001 │    1/3    │₹375K  │Jan1│Cash   │ ✓Paid│
│BK-002 │    2/5    │₹240K  │Jan5│Bank   │ ✓Paid│
│BK-003 │    1/2    │₹1.05M │Jan7│Check  │ ✓Paid│
│       │           │       │    │       │      │
└────────────────────────────────────────────────┘

Features:
- Search by booking code or customer
- Filter by date range
- Export to Excel/PDF
- Payment method display
- Status indicator
```

### Record Payment Modal
```
┌────────────────────────────────────┐
│ Record Payment                     │
├────────────────────────────────────┤
│                                    │
│ Booking Code    │ BK-001           │
│                 └──────────────────┘
│                                    │
│ Installment     │ Installment 2/5  │
│                 └──────────────────┘
│                                    │
│ Due Amount      │ ₹240,000         │
│                 └──────────────────┘
│                                    │
│ Amount Paid *   │ ₹240,000         │
│                 └──────────────────┘
│ (Can be partial payment)           │
│                                    │
│ Payment Date *  │ 2024-01-05       │
│                 └──────────────────┘
│                                    │
│ Payment Method  │ [Bank Transfer ▼]│
│                 └──────────────────┘
│                                    │
│ Notes                              │
│ ┌──────────────────────────────────┐
│ │ Payment received via wire        │
│ └──────────────────────────────────┘
│                                    │
│ ☐ Generate Invoice                │
│                                    │
│       [Submit] [Cancel]            │
└────────────────────────────────────┘
```

---

## 📊 Reports

### Project Report View
```
┌────────────────────────────────────────────┐
│ Project Report: Downtown Shopping Center  │
├────────────────────────────────────────────┤
│
│ Project Status: In Progress
│ Timeline: 2024-01-01 to 2024-12-31
│ Manager: John Smith
│
│ ┌─────────────────────────────────────┐
│ │ Summary Statistics                  │
│ │ ─────────────────────────────────── │
│ │ Total Plots: 48 (✓ Available: 42)   │
│ │ Bookings: 8  (✓ Paid: ₹3.5M)        │
│ │ Revenue: ₹5.2M (Expected: ₹12M)     │
│ └─────────────────────────────────────┘
│
│ Plots Status Breakdown
│ ┌──────────────────────┐
│ │ Available: ████ 42   │
│ │ Booked:    ███ 5     │
│ │ Sold:      ██ 1      │
│ └──────────────────────┘
│
│ Team Assignments
│ ├─ John Smith (Project Manager)
│ ├─ Sarah Jones (Sales)
│ └─ Mike Davis (Operations)
│
│ Recent Activity
│ ├─ Plot P-047 booked (Jan 7)
│ ├─ Payment received (Jan 5)
│ └─ Block B finalized (Jan 1)
│
│ [📥 Export PDF] [📊 Export Excel]
└────────────────────────────────────────────┘
```

---

## ⚙️ Settings Page

```
┌────────────────────────────────────┐
│ Real Estate Settings               │
├────────────────────────────────────┤
│                                    │
│ Default Currency    │ [INR ▼]      │
│                     └──────────────┘
│                                    │
│ Decimal Places      │ [2 ▼]        │
│                     └──────────────┘
│                                    │
│ Tax Rate (%)        │ 18            │
│                     └──────────────┘
│                                    │
│ Default Payment     │ [30/70 ▼]    │
│ Plan                └──────────────┘
│                                    │
│ Email Notifications │ [✓ Enabled]   │
│                     └──────────────┘
│                                    │
│ Send booking       │ ☑             │
│ confirmation       │               │
│                                    │
│ Send payment       │ ☑             │
│ reminder           │               │
│                                    │
│        [Save Settings] [Cancel]    │
└────────────────────────────────────┘
```

---

## 🔄 Status Workflows

### Project Status Flow
```
     ┌──────────┐
     │ Planning │
     └─────┬────┘
           │
     ┌─────▼──────────┐
     │ In Progress    │
     └─────┬──────────┘
           │
     ┌─────▼──────────┐
     │   Completed    │
     └────────────────┘
```

### Plot Status Flow
```
Available ──┐
            │
            ▼
(Customer books)
            │
            ▼
        Booked ──┐
                 │
    (Payment complete)
                 │
                 ▼
              Sold
                 │
    or (Cancelled)
                 │
                 ▼
            Available
```

### Booking Status Flow
```
Pending ──┐
          │ (Confirm)
          ▼
     Confirmed ──┐
                 │
    (Payment complete)
                 │
                 ▼
         Converted to Sale
                 │
    or (Customer cancels)
                 │
                 ▼
             Cancelled
```

### Installment Status
```
Pending ──┐
          │ (Payment received)
          ▼
         Paid
         
Pending ──┐
          │ (Due date passed, unpaid)
          ▼
         Overdue
         
Overdue ──┐
          │ (Partial payment)
          ▼
        Partial
```

---

## 🎨 Color Coding Reference

### Status Badges
```
🟢 Green      - Available / Sold / Active / Success
🟡 Yellow     - Booked / Pending / Warning
🔵 Blue       - Converted / Processing / Info
⚪ Gray       - Reserved / Disabled / Default
🔴 Red        - Blocked / Cancelled / Error / Overdue
```

### Button Types
```
[+ Primary Button]     - Create new records (Green/Blue)
[Secondary Button]     - Default actions (Gray)
[Danger Button]        - Delete/Cancel (Red)
[Info/Help Button]     - Show details (Blue)
```

---

## 📱 Responsive Design

### Desktop View (1200px+)
- Two-column layouts (form + sidebar)
- Full DataTables with multiple columns
- All buttons visible
- Charts and graphs displayed

### Tablet View (768px-1199px)
- Single column with collapsible sections
- Simplified DataTables (some columns hidden)
- Buttons stacked or condensed
- Charts responsive

### Mobile View (< 768px)
- Full single column
- Minimal DataTables (essential columns only)
- Buttons stacked vertically
- Dropdowns full-width
- Charts converted to simplified summaries

---

## ♿ Accessibility Features

```
✓ Keyboard navigation (Tab, Enter, Escape)
✓ ARIA labels for screen readers
✓ Color not sole differentiator (icons + colors)
✓ Form labels associated with inputs
✓ Sufficient color contrast
✓ Focus indicators visible
✓ Error messages linked to form fields
```

---

## 🖥️ File Upload Areas

Where you can upload documents/files:
```
Project Page
├─ Project documents
├─ Site photos
└─ Legal paperwork

Booking Page
├─ Agreement documents
├─ Customer ID copies
└─ Payment proof

Communications
└─ Attachments to notes
```

Files stored in: `uploads/real_estate/` (organized by project)

---

## 📈 Data Export Options

From various pages:
```
Projects
├─ Export to CSV
└─ Export to PDF

Plots
├─ Export to CSV
└─ Export to PDF

Bookings
├─ Export to CSV
└─ Export to PDF (with installments)

Payments
├─ Export to CSV (with payment details)
└─ Export to PDF (invoice format)

Reports
├─ Export to PDF (formatted report)
└─ Export to Excel (detailed data)
```

---

## 📞 Quick Actions

Buttons/links available throughout:
```
[+ New Record]        - Create new item
[✏️ Edit]             - Modify existing item
[🗑 Delete]           - Remove item
[👁 View]             - Open details
[💾 Save]             - Save changes
[📥 Export]           - Download data
[🔍 Search]           - Find records
[📋 Copy]             - Duplicate item
[📞 Contact]          - Send message
[📊 Report]           - Generate report
[⚙️ Settings]        - Configure options
[↩️ Back]             - Go back
[✓ Confirm]           - Confirm action
[✗ Cancel]            - Cancel action
```

---

## 🔔 Notifications

### Success Messages (Green)
```
✓ Project added successfully!
✓ Plot updated!
✓ Booking created - Code: BK-001-2024
✓ Payment recorded!
```

### Warning Messages (Yellow)
```
⚠️ This project has bookings - they will be deleted
⚠️ Installment payment is overdue
⚠️ Plot status cannot be changed (already booked)
```

### Error Messages (Red)
```
✗ Project code already exists
✗ Customer not selected
✗ Payment amount exceeds installment
✗ Database error - please try again
```

### Info Messages (Blue)
```
ℹ️ No records found
ℹ️ Loading data...
ℹ️ 3 overdue payments require attention
```

---

## 🎯 Common User Tasks & UI Locations

| Task | Where to Go |
|------|-------------|
| Create project | Real Estate → Projects → New Project |
| Add plots to project | Real Estate → Plots → New Plot |
| Book a plot | Real Estate → Bookings → New Booking |
| Record payment | Real Estate → Bookings → (open booking) → Record Payment |
| View dashboard | Real Estate (main link) |
| Filter plots | Real Estate → Plots → (Project dropdown) |
| See project details | Real Estate → Projects → (click project) |
| Generate report | Real Estate → Reports → (select project) |
| Manage team | Real Estate → Projects → (open project) → Team Assignments |
| Change settings | Real Estate → Settings |

---

**This visual guide complements the functional guides. For detailed instructions, see QUICK_START_GUIDE.md or TROUBLESHOOTING.md**

*Last Updated: January 2024 | Module Version: 1.0.0*
